package letraE;

public class Calculator {
    public double div (double a, double b) {

        return a/b;
    }

    public double log10(double a){

        return Math.log10(a);
    }

}
