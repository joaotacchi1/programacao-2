package classes;

import java.util.Random;

public class MedidorFarenheit {
    
    public double getTemperaturaFarenheit() {
        return new Random().nextDouble();
    }
    
}
