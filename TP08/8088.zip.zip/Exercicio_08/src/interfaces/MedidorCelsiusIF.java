package interfaces;

public interface MedidorCelsiusIF {
    
    double medirTemperatura();
    
}
