package lanchonete;

public abstract class FabricaAbstrataSanduiches {
    public abstract Sanduiche SanduicheFactory(String pao, String presunto, String queijo, String salada);
}
