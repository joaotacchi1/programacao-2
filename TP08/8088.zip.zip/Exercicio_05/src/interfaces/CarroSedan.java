package interfaces;

public interface CarroSedan {
    
    void exibirInfoSedan();
    
}
