package interfaces;

public interface CarroPopular {
    
    void exibirInfoPopular();
    
}
