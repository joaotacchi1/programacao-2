package interfaces;

public interface FabricaDeCarro {
    
    public CarroSedan criarCarroSedan();
    public CarroPopular criarCarroPopular();
    
}
