package principal;

public class Triangulo implements FormaGeometrica{

    @Override
    public void desenhar() {
        System.out.println("Forma geométrica criada foi: triangulo");
    }
}
