package principal;

public interface FormaGeometrica {
    public void desenhar();
}
