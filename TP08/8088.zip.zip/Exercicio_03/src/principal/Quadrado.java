package principal;

public class Quadrado implements FormaGeometrica{

    @Override
    public void desenhar() {
        System.out.println("Forma geométrica criada foi: quadrado");
    }
}
