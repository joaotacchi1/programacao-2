package principal;

public interface Animal {
    public String getNomeEspecie();
    public String getNomeAnimal();
}
