package principal;

public abstract class Veiculo {
    public abstract float acelera(float velocidade);
    public abstract void parar();
}
