package principal;

public class Main {
    public static void main(String[] args) {

        //Um carro nada mais é do que um objeto particular ou público para locomoção dentro ou fora da cidade em que mora
        //com o objetivo de te locomover até certo local pré determinado ou não. É um veículo de 4 rodas que serve para
        //transporte tanto de pessoas quanto de cargas. As principais características de um carro são os fatores: Placa,
        //Modelo do carro, Chassi, Cor, Ano de fabricação, condições de uso e a empresa fabricante, etc. Algumas das
        //ações que o carro exerce são as de: Ligar, desligar, acelerar, freiar, dar seta, engatar a ré, ligar o parabrisas,
        //dentre outras funcionalidades.
        //Verbos: Ligar, desligar, acelerar, freiar, engatar, freiar
        //Substantivos: Placa, modelo do carro, chassi, cor, ano de fabricação, condições de uso, empresa fabricante
    }
}
